Rake

  RVM allows you to run rake tasks across multiple ruby versions, for example:

    $ rvm all do rake spec

  or:

    $ rvm 1.8.6,1.9.1 do rake spec

JSON Summary

  Add a --json flag prior to the word 'do' and a JSON summary will be printed out at the end of the run.

YAML Summary

  Add a --yaml flag prior to the word 'do' and a YAML summary will be printed out at the end of the run.

